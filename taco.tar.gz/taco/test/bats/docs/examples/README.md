# Examples

This directory contains example .bats files.
See the [bats-core wiki][examples] for more details.

[examples]: (/bats-core/bats-core/wiki/Examples)
