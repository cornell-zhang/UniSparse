Formats
=======================
.. toctree::
   :maxdepth: 3

   mode_format
   format_class
   format_funcs


