User-Defined Functions
=========================

Users can defined their own functions to execute with PyTaco. These functions  
must be implemented in a C header file and can be called using the following
functions.

.. currentmodule:: pytaco

.. autosummary::
   :toctree: functions

   apply
   set_udf_dir

