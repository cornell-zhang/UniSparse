PyTaco Index Variables
=======================
.. autoclass:: pytaco.index_var
