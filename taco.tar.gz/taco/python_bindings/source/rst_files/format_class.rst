Tensor Format Object
=======================
.. autoclass:: pytaco.format