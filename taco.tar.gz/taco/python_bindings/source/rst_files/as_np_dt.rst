Converting PyTaco Data Type to NumPy
======================================

.. autofunction:: pytaco.as_np_dtype
