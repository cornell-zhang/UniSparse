#ifndef TACO_TACO_H
#define TACO_TACO_H

#include "taco/tensor.h"
#include "taco/format.h"
#include "taco/index_notation/tensor_operator.h"
#include "taco/index_notation/index_notation.h"

#endif
