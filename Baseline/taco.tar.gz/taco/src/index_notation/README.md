This directory contains the API and data structures for the index
notation language that describes computations on tensors.  It also
contains utilities such as visitors, rewriters, and printers.  For
more information about the index notation API, see the [include
directory](https://github.com/tensor-compiler/taco/tree/master/include/taco/index_notation)
