The parser turns a textual index expression into an index expression data
structure from the `expr` module.  It is usually more convenient to create the
index expressions directly through the `expr` API, but the parser is useful
when building tools that receive the index expressions as text.
