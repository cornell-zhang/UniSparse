The `storage` module manages tensor index data structure, packing and iterating
over these, inserting values, and reading/writing values from/to files.
