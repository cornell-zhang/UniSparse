export TACO_INCLUDE_DIR=$(pwd)/../../include
export TACO_LIBRARY_DIR=$(pwd)/../../build/lib
export TACO_CONVERT_GEN_DIR=$(pwd)/../../build
