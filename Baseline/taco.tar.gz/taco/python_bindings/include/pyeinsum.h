#ifndef TACO_PY_EINSUM_H
#define TACO_PY_EINSUM_H

#include <pybind11/pybind11.h>
#include "taco/parser/parser.h"

namespace py = pybind11;


#endif //TACO_PY_EINSUM_H
