.. PyTaco documentation master file, created by
   sphinx-quickstart on Sat May 25 19:06:12 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Table of Contents
==================================

.. toctree::
   :maxdepth: 3

   rst_files/datatype
   rst_files/format
   rst_files/file_io
   rst_files/sched
   rst_files/index_expressions
   rst_files/tensors
   rst_files/parsers
   rst_files/udfs






