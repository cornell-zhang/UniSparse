Evaluating String Expressions
==============================

.. currentmodule:: pytaco

.. autosummary::
   :toctree: functions

   evaluate
   einsum
