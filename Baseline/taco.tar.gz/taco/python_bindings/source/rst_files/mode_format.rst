Mode Formats
=======================
.. autoclass:: pytaco.mode_format
