Index Expression Objects
==========================

.. autoclass:: pytaco.index_expression