PyTaco Data Type Object
=================================

.. autoclass:: pytaco.dtype
