Tensor Class
=================

.. autoclass:: pytaco.tensor

