Scheduling Commands
======================

.. currentmodule:: pytaco

.. autosummary::
   :toctree: functions

   get_num_threads
   set_num_threads
   set_parallel_schedule
   get_parallel_schedule