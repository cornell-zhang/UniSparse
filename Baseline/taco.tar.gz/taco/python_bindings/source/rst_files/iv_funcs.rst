Convenience Functions
======================

.. currentmodule:: pytaco

.. autosummary::
   :toctree: functions

   get_index_vars