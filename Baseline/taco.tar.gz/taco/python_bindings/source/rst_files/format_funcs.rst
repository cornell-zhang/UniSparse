Format Functions
===================

.. autofunction:: pytaco.is_dense